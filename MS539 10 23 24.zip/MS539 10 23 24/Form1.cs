﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_10_23_24
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        class course
        {
            public string ClassNum;
            public string ClassName;
            public string preReq;
            public string description;

            public course(string classNum, string className, string preReq, string description)
            {
                this.ClassNum = classNum;
                this.ClassName = className;
                this.preReq = preReq;
                this.description = description;
            }

            public void display()
            {
                MessageBox.Show("class num = " + ClassNum + " class name " + ClassName);
                MessageBox.Show("prereq = " + preReq + "desc = " + description);
            }

        }

        class semester
        {
            public string semesterName;
            public List<course> courseList = new List <course>();

            public semester(string semesterName, List<course>listOfCourses)
            { 
                this.semesterName = semesterName;
                for (int i = 0;i < listOfCourses.Count; i++)
                {
                    courseList.Add(listOfCourses[i]);
                }

            }

            public void display()
            {
                MessageBox.Show("Semester: " + semesterName);
                for (int i= 0;i < courseList.Count;i++  )
                {
                    courseList[i].display();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            course c1 = new course("MS539", "Intro to prog", "none", "c#");
           // c1.display();


            course c2 = new course("MS549", "Data Structures", "MS539", "c++");
          //  c2.display();

            List<course> springCourses = new List<course>();
            springCourses.Add(c1);
            springCourses.Add(c2);
            semester spring2025 = new semester("Spring 2025", springCourses);
            spring2025.display();

        }
    }
}
